package com.example.AcutionWebApplication.service;

import com.example.AcutionWebApplication.model.Contact_Us;

public interface UserContact_Us {

	public Contact_Us contactSave(Contact_Us conUs);

}
