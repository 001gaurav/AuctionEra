package com.example.AcutionWebApplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.AcutionWebApplication.model.feedBackDeatils;

public interface FeedBackReository extends JpaRepository<feedBackDeatils, Integer>{

}
