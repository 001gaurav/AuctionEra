package com.example.AcutionWebApplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.AcutionWebApplication.model.Contact_Us;

public interface Contact_UsRepository extends JpaRepository<Contact_Us, Integer> {

	

	
}
