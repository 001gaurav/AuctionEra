package com.example.AcutionWebApplication.service;

import com.example.AcutionWebApplication.model.BidDetails;

public interface BidDeatilsService {

	public BidDetails bidSave(BidDetails bidDetails);

}
