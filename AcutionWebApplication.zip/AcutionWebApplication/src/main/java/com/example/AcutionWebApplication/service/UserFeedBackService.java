package com.example.AcutionWebApplication.service;

import com.example.AcutionWebApplication.model.feedBackDeatils;

public interface UserFeedBackService {

	public feedBackDeatils saveFeedBack(feedBackDeatils fBDeatils);

}
