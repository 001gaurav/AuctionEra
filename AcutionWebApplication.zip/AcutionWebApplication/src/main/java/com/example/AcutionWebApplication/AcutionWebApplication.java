package com.example.AcutionWebApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcutionWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(AcutionWebApplication.class, args);
	}

}
